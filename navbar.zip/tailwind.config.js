module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}', // Update paths as necessary for your project
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
