import React from 'react'
import Sidebar from './compnent/Sidebar'
import './index.css'; 

const App = () => {
  return (
    <div>
      <Sidebar></Sidebar>
    </div>
  )
}

export default App
